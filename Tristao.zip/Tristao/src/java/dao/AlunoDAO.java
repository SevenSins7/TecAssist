/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Cristian
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import modelo.Aluno;

/**
 * 
 * Classe de Persistência de dados dos objetos de Aluno
 * é "filha" da Classe DAO. 
 *
 */

public class AlunoDAO extends DAO {

	public void alterar(Aluno aluno) {
		try {
			Connection conexao = getConexao();

			PreparedStatement pstmt = conexao
					.prepareStatement("Update tbaluno SET nome = ?, turma = ?, professor = ?, audio_nome = ?, foto_aluno = ?"
							+ " WHERE matricula = ? ");
			pstmt.setString(1, aluno.getNome());
			pstmt.setString(2, aluno.getTurma());
			pstmt.setString(3, aluno.getProfessor());
//                        if(aluno.getAudio_nome() != null) {
//                            pstmt.setBlob(4, aluno.getAudio_nome());
//                        }
//                        if(aluno.getFoto_aluno() != null) {
//                            pstmt.setBlob(5, aluno.getFoto_aluno());
//                        }
                        
                        pstmt.setLong(6, aluno.getMatricula());
			pstmt.execute();
			pstmt.close();
			conexao.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir(Aluno aluno) {
		try {
			Connection conexao = getConexao();
			PreparedStatement pstm = conexao
					.prepareStatement("Delete from	tbaluno where matricula = ? ");
			pstm.setLong(1, aluno.getMatricula());
			pstm.execute();
			pstm.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean existe(Aluno aluno) {
		boolean achou = false;
		try {
			Connection conexao = getConexao();
			PreparedStatement pstm = conexao
					.prepareStatement("Select * from tbaluno where matricula =	?");
			pstm.setLong(1, aluno.getMatricula());
			ResultSet rs = pstm.executeQuery();
			if (rs.next()) {
				achou = true;
			}
			pstm.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return achou;
	}

	public void inserir(Aluno aluno) {
		try {
			Connection conexao = getConexao();
			PreparedStatement pstm = conexao
					.prepareStatement("Insert into	tbaluno (matricula, nome, telefone, email, datacadastro) values	(?,?,?,?,?)");
			pstm.setLong(1, aluno.getMatricula());
			pstm.setString(2, aluno.getNome());
			pstm.setString(3, aluno.getTurma());
			pstm.setString(4, aluno.getProfessor());
			
			pstm.execute();
			pstm.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Aluno> listar() {
		List<Aluno> lista = new ArrayList<>();
		try {
			Connection conexao = getConexao();
			Statement stm = conexao.createStatement();
			ResultSet rs = stm.executeQuery("Select * from tbaluno");
			while (rs.next()) {
				Aluno aluno = new Aluno();
				aluno.setMatricula(rs.getLong("matricula"));
				aluno.setNome(rs.getString("nome"));
				aluno.setTurma(rs.getString("telefone"));
				aluno.setProfessor(rs.getString("email"));
				
				lista.add(aluno);
			}
			stm.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista;
	}

	public Aluno consultar(Aluno aluno) {
		try {
			Connection conexao = getConexao();
			PreparedStatement pstm = conexao
					.prepareStatement("Select * from tbaluno where matricula =	?");
			pstm.setLong(1, aluno.getMatricula());
			ResultSet rs = pstm.executeQuery();
			if (rs.next()) {
				aluno.setMatricula(rs.getLong("matricula"));
				aluno.setNome(rs.getString("nome"));
				aluno.setTurma(rs.getString("turma"));
				aluno.setProfessor(rs.getString("professor"));
				
			}
			pstm.close();
			conexao.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return aluno;
	}
}