/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Cristian
 */

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.FetchType;
import javax.persistence.Lob;

/**
 * 
 * Classe de entidade que possui os atributos do aluno 
 *
 */
public class Aluno implements Serializable {
	private static final long serialVersionUID = -309513637403441918L;

	private Long matricula;
	private String nome;
	private String turma;
	private String professor;
      
        @Lob
        @Basic(fetch = FetchType.EAGER)
        private byte[] audio_nome;

        @Lob
        @Basic(fetch = FetchType.EAGER)
        private byte[] foto_aluno;


	public Aluno() {}

	public Aluno(Long matricula) {
		super();
		this.matricula = matricula;
	}

	public Aluno(Long matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}

	public Long getMatricula() {
		return matricula;
	}

	public String getNome() {
		return nome;
	}


	public void setMatricula(Long matricula) {
		this.matricula = matricula;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

        public String getTurma() {
            return turma;
        }

        public void setTurma(String turma) {
            this.turma = turma;
        }

        public String getProfessor() {
            return professor;
        }

        public void setProfessor(String professor) {
            this.professor = professor;
        }

        public byte[] getAudio_nome() {
            return audio_nome;
        }

        public void setAudio_nome(byte[] audio_nome) {
            this.audio_nome = audio_nome;
        }

        public byte[] getFoto_aluno() {
            return foto_aluno;
        }

        public void setFoto_aluno(byte[] foto_aluno) {
            this.foto_aluno = foto_aluno;
        }

        

}
